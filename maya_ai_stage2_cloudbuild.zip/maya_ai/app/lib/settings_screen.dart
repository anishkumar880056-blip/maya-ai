import 'package:flutter/material.dart';
import 'settings_store.dart';
import 'strings.dart';
import 'theme.dart';

class SettingsScreen extends StatefulWidget {
  final SettingsStore settings;
  const SettingsScreen({super.key, required this.settings});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late String _lang = widget.settings.language;
  late final _url = TextEditingController(text: widget.settings.backendUrl);
  late final _token = TextEditingController(text: widget.settings.appToken);
  late final _persona = TextEditingController(text: widget.settings.personality);

  SettingsStore get s => widget.settings;

  @override
  void dispose() {
    _url.dispose();
    _token.dispose();
    _persona.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await s.save(
      language: _lang,
      backendUrl: _url.text,
      personality: _persona.text,
      appToken: _token.text,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr(s, 'saved'))));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr(s, 'settings'), style: const TextStyle(color: kCyan, letterSpacing: 2))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(tr(s, 'language')),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'en', label: Text('English')),
              ButtonSegment(value: 'hi', label: Text('हिन्दी')),
            ],
            selected: {_lang},
            onSelectionChanged: (v) => setState(() => _lang = v.first),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _url,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(labelText: tr(s, 'backendUrl'), helperText: tr(s, 'backendHelp'), helperMaxLines: 3),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _token,
            obscureText: true,
            enableSuggestions: false,
            autocorrect: false,
            decoration: InputDecoration(labelText: tr(s, 'token'), helperText: tr(s, 'tokenHelp')),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _persona,
            maxLength: 300,
            maxLines: 3,
            decoration: InputDecoration(labelText: tr(s, 'personality'), helperText: tr(s, 'personalityHelp'), helperMaxLines: 2),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: Text(tr(s, 'save'))),
        ],
      ),
    );
  }
}
