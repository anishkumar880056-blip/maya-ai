import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'api_client.dart';
import 'chat_screen.dart';
import 'maya_core.dart';
import 'settings_screen.dart';
import 'settings_store.dart';
import 'strings.dart';
import 'theme.dart';

class HomeScreen extends StatefulWidget {
  final SettingsStore settings;
  const HomeScreen({super.key, required this.settings});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _input = TextEditingController();
  bool? _online; // null = checking

  SettingsStore get s => widget.settings;

  @override
  void initState() {
    super.initState();
    _check();
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _check() async {
    setState(() => _online = null);
    final ok = await ApiClient(s).health();
    if (mounted) setState(() => _online = ok);
  }

  void _openChat([String? first]) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ChatScreen(settings: s, initialMessage: first)),
    );
  }

  Future<void> _openSettings() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => SettingsScreen(settings: s)),
    );
    _check();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final orb = math.min(width * 0.85, 340.0);
    final statusText = _online == null
        ? tr(s, 'checking')
        : _online!
            ? tr(s, 'connected')
            : tr(s, 'offline');
    final statusColor = _online == null ? kBlue : (_online! ? kCyan : Colors.orangeAccent);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.2),
            radius: 1.1,
            colors: [Color(0xFF0B2548), kBg],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 8, 0),
                child: Row(
                  children: [
                    const Text('MAYA AI',
                        style: TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w300, letterSpacing: 6, color: kCyan)),
                    const Spacer(),
                    IconButton(
                      tooltip: tr(s, 'chat'),
                      icon: const Icon(Icons.chat_bubble_outline, color: kCyan),
                      onPressed: () => _openChat(),
                    ),
                    IconButton(
                      tooltip: tr(s, 'settings'),
                      icon: const Icon(Icons.settings_outlined, color: kCyan),
                      onPressed: _openSettings,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        MayaCore(state: MayaState.idle, size: orb),
                        const SizedBox(height: 12),
                        InkWell(
                          borderRadius: BorderRadius.circular(20),
                          onTap: _check,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.circle, size: 10, color: statusColor),
                                const SizedBox(width: 8),
                                Flexible(
                                    child: Text(statusText,
                                        style: TextStyle(color: statusColor, fontSize: 13))),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: TextField(
                  controller: _input,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (v) {
                    if (v.trim().isEmpty) return;
                    final text = v.trim();
                    _input.clear();
                    _openChat(text);
                  },
                  decoration: InputDecoration(
                    hintText: tr(s, 'askHint'),
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.arrow_upward, color: kCyan),
                      tooltip: tr(s, 'send'),
                      onPressed: () {
                        final text = _input.text.trim();
                        if (text.isEmpty) return;
                        _input.clear();
                        _openChat(text);
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
