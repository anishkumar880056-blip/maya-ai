import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'theme.dart';

enum MayaState { idle, listening, thinking, speaking }

/// Animated 2D holographic core. One widget, four visual states.
class MayaCore extends StatefulWidget {
  final MayaState state;
  final double size;
  const MayaCore({super.key, required this.state, this.size = 300});

  @override
  State<MayaCore> createState() => _MayaCoreState();
}

class _MayaCoreState extends State<MayaCore> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => CustomPaint(
          size: Size.square(widget.size),
          painter: _OrbPainter(_c.value, widget.state),
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  final double t; // 0..1 loops every 8 seconds
  final MayaState state;
  _OrbPainter(this.t, this.state);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final phase = t * 2 * math.pi;

    // Integer multipliers keep the loop seamless.
    final spin = switch (state) {
      MayaState.idle => 1,
      MayaState.listening => 2,
      MayaState.thinking => 6,
      MayaState.speaking => 3,
    };
    final pulseAmp = switch (state) {
      MayaState.idle => 0.02,
      MayaState.listening => 0.05,
      MayaState.thinking => 0.03,
      MayaState.speaking => 0.07,
    };
    final pulse = 1 + pulseAmp * math.sin(phase * 8);

    // Outer glow
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        kCyan.withAlpha(110),
        kBlue.withAlpha(50),
        Colors.transparent,
      ], stops: const [0.25, 0.6, 1.0])
          .createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r, glow);

    // Rotating arc rings
    for (var i = 0; i < 4; i++) {
      final ringR = r * (0.52 + 0.14 * i) * pulse;
      final dir = i.isEven ? 1 : -1;
      final p = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0 - i * 0.2
        ..strokeCap = StrokeCap.round
        ..color = (i.isEven ? kCyan : kBlue).withAlpha(200 - i * 30);
      final start = phase * spin * dir + i * 1.3;
      final sweep = state == MayaState.thinking ? math.pi * 0.5 : math.pi * (1.1 - i * 0.15);
      canvas.drawArc(Rect.fromCircle(center: c, radius: ringR), start, sweep, false, p);
      canvas.drawArc(Rect.fromCircle(center: c, radius: ringR), start + math.pi, sweep * 0.6, false, p);
    }

    // Tick ring
    final tick = Paint()
      ..color = kCyan.withAlpha(70)
      ..strokeWidth = 1;
    for (var i = 0; i < 72; i++) {
      final a = i / 72 * 2 * math.pi + phase * spin * 0.25;
      final len = i % 6 == 0 ? 10.0 : 5.0;
      final o = Offset(math.cos(a), math.sin(a));
      canvas.drawLine(c + o * (r * 0.97 - len), c + o * (r * 0.97), tick);
    }

    // Voice bars (listening = inward-moving, speaking = stronger)
    if (state == MayaState.listening || state == MayaState.speaking) {
      final bar = Paint()
        ..color = kCyan
        ..strokeWidth = 3
        ..strokeCap = StrokeCap.round;
      final base = r * 0.40;
      final amp = state == MayaState.speaking ? r * 0.16 : r * 0.09;
      for (var i = 0; i < 48; i++) {
        final a = i / 48 * 2 * math.pi;
        final v = (math.sin(phase * 3 + i * 0.7) * 0.5 + 0.5) *
            (math.sin(phase * 5 - i * 0.4) * 0.5 + 0.5);
        final o = Offset(math.cos(a), math.sin(a));
        canvas.drawLine(c + o * base, c + o * (base + 4 + amp * v), bar);
      }
    }

    // Core sphere
    final coreR = r * 0.30 * pulse;
    final core = Paint()
      ..shader = RadialGradient(colors: [
        Colors.white,
        kCyan,
        kBlue,
      ], stops: const [0.0, 0.45, 1.0])
          .createShader(Rect.fromCircle(center: c, radius: coreR));
    canvas.drawCircle(c, coreR, core);
    canvas.drawCircle(
      c,
      coreR * 1.18,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = kCyan.withAlpha(160),
    );
  }

  @override
  bool shouldRepaint(_OrbPainter old) => old.t != t || old.state != state;
}
