import 'dart:convert';
import 'package:http/http.dart' as http;
import 'settings_store.dart';

class ChatMessage {
  final String role; // 'user' or 'assistant'
  final String content;
  const ChatMessage(this.role, this.content);
  Map<String, dynamic> toJson() => {'role': role, 'content': content};
}

class ApiException implements Exception {
  final String message;
  const ApiException(this.message);
  @override
  String toString() => message;
}

class ApiClient {
  final SettingsStore settings;
  const ApiClient(this.settings);

  Future<bool> health() async {
    try {
      final res = await http
          .get(Uri.parse('${settings.backendUrl}/health'))
          .timeout(const Duration(seconds: 6));
      if (res.statusCode != 200) return false;
      final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      return data['status'] == 'ok';
    } catch (_) {
      return false;
    }
  }

  Future<String> chat(List<ChatMessage> history) async {
    if (settings.appToken.isEmpty) {
      throw const ApiException('App token is missing. Add it in Settings.');
    }
    final recent = history.length > 20 ? history.sublist(history.length - 20) : history;
    final http.Response res;
    try {
      res = await http
          .post(
            Uri.parse('${settings.backendUrl}/chat'),
            headers: {
              'Content-Type': 'application/json',
              'X-MAYA-TOKEN': settings.appToken,
            },
            body: jsonEncode({
              'messages': recent.map((m) => m.toJson()).toList(),
              'language': settings.language,
              'personality': settings.personality,
              'memory': <String>[], // opt-in memory arrives in Stage 5
            }),
          )
          .timeout(const Duration(seconds: 60));
    } catch (_) {
      throw const ApiException('Cannot reach the server. Check the backend URL in Settings.');
    }
    final body = utf8.decode(res.bodyBytes);
    if (res.statusCode == 200) {
      return (jsonDecode(body) as Map<String, dynamic>)['reply'] as String;
    }
    if (res.statusCode == 401) {
      throw const ApiException('The app token does not match the server. Check Settings.');
    }
    String detail = 'Server error (${res.statusCode}).';
    try {
      detail = (jsonDecode(body) as Map<String, dynamic>)['detail'].toString();
    } catch (_) {}
    throw ApiException(detail);
  }
}
