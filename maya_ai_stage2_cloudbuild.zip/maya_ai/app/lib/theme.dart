import 'package:flutter/material.dart';

const kCyan = Color(0xFF00E5FF);
const kBlue = Color(0xFF2979FF);
const kBg = Color(0xFF030B1A);
const kPanel = Color(0xFF0A1B33);
const kText = Color(0xFFE6F7FF);

final ThemeData mayaTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  scaffoldBackgroundColor: kBg,
  colorScheme: const ColorScheme.dark(
    primary: kCyan,
    secondary: kBlue,
    surface: kPanel,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: Colors.transparent,
    elevation: 0,
    foregroundColor: kText,
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: kPanel,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: kCyan.withAlpha(90)),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(color: kCyan.withAlpha(90)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: kCyan, width: 1.5),
    ),
  ),
);
