import 'package:flutter/material.dart';
import 'api_client.dart';
import 'maya_core.dart';
import 'settings_store.dart';
import 'strings.dart';
import 'theme.dart';

class _Item {
  final String role; // user | assistant | error
  final String text;
  const _Item(this.role, this.text);
}

class ChatScreen extends StatefulWidget {
  final SettingsStore settings;
  final String? initialMessage;
  const ChatScreen({super.key, required this.settings, this.initialMessage});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<_Item> _items = [];
  bool _busy = false;

  SettingsStore get s => widget.settings;

  @override
  void initState() {
    super.initState();
    final first = widget.initialMessage;
    if (first != null && first.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _send(first));
    }
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _send(String raw) async {
    final text = raw.trim();
    if (text.isEmpty || _busy) return;
    setState(() {
      _items.add(_Item('user', text));
      _busy = true;
    });
    _toBottom();
    try {
      final history = _items
          .where((i) => i.role != 'error')
          .map((i) => ChatMessage(i.role, i.text))
          .toList();
      final reply = await ApiClient(s).chat(history);
      if (!mounted) return;
      setState(() => _items.add(_Item('assistant', reply)));
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _items.add(_Item('error', e.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
      _toBottom();
    }
  }

  Widget _bubble(_Item i) {
    final isUser = i.role == 'user';
    final isError = i.role == 'error';
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        decoration: BoxDecoration(
          color: isError
              ? Colors.red.withAlpha(40)
              : isUser
                  ? kBlue.withAlpha(90)
                  : kPanel,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: isError ? Colors.redAccent : (isUser ? kBlue : kCyan.withAlpha(110))),
        ),
        child: SelectableText(i.text, style: const TextStyle(color: kText, fontSize: 15, height: 1.35)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr(s, 'chat'), style: const TextStyle(letterSpacing: 2, color: kCyan)),
        actions: [
          IconButton(
            tooltip: tr(s, 'newChat'),
            icon: const Icon(Icons.add_comment_outlined, color: kCyan),
            onPressed: _busy ? null : () => setState(_items.clear),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 110,
            child: Center(
              child: MayaCore(state: _busy ? MayaState.thinking : MayaState.idle, size: 110),
            ),
          ),
          Expanded(
            child: _items.isEmpty
                ? Center(child: Text(tr(s, 'emptyChat'), style: TextStyle(color: kText.withAlpha(140))))
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _items.length,
                    itemBuilder: (_, k) => _bubble(_items[k]),
                  ),
          ),
          if (_busy)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(tr(s, 'thinking'), style: const TextStyle(color: kCyan, fontSize: 13)),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
              child: TextField(
                controller: _input,
                minLines: 1,
                maxLines: 4,
                textInputAction: TextInputAction.send,
                onSubmitted: (v) {
                  _input.clear();
                  _send(v);
                },
                decoration: InputDecoration(
                  hintText: tr(s, 'askHint'),
                  suffixIcon: IconButton(
                    tooltip: tr(s, 'send'),
                    icon: const Icon(Icons.arrow_upward, color: kCyan),
                    onPressed: _busy
                        ? null
                        : () {
                            final t = _input.text;
                            _input.clear();
                            _send(t);
                          },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
