import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsStore extends ChangeNotifier {
  static const _secure = FlutterSecureStorage();

  String language = 'en';
  String backendUrl = 'http://10.0.2.2:8000';
  String personality = '';
  String appToken = '';

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    language = p.getString('language') ?? language;
    backendUrl = p.getString('backendUrl') ?? backendUrl;
    personality = p.getString('personality') ?? personality;
    appToken = await _secure.read(key: 'appToken') ?? '';
    notifyListeners();
  }

  Future<void> save({
    required String language,
    required String backendUrl,
    required String personality,
    required String appToken,
  }) async {
    this.language = language;
    this.backendUrl = backendUrl.trim().replaceAll(RegExp(r'/+$'), '');
    this.personality = personality.trim();
    this.appToken = appToken.trim();
    final p = await SharedPreferences.getInstance();
    await p.setString('language', this.language);
    await p.setString('backendUrl', this.backendUrl);
    await p.setString('personality', this.personality);
    await _secure.write(key: 'appToken', value: this.appToken);
    notifyListeners();
  }
}
