# Stage 2 setup (Flutter app)

1. Install Flutter (flutter.dev) and Android Studio (for the Android SDK). Run `flutter doctor`.
2. Create the Android project shell:
       flutter create --org com.maya --project-name maya_ai --platforms android maya_ai_app
3. Copy `app/lib/` and `app/pubspec.yaml` from this zip over `maya_ai_app/lib/` and `maya_ai_app/pubspec.yaml`.
4. Edit `maya_ai_app/android/app/src/main/AndroidManifest.xml`:
   - Before `<application`, add: `<uses-permission android:name="android.permission.INTERNET"/>`
   - In `<application`, set `android:label="MAYA AI"` and add `android:usesCleartextTraffic="true"` (needed only while the backend is plain http; remove it once you host the backend on https).
5. Edit `maya_ai_app/android/app/build.gradle` (or `build.gradle.kts`): set `minSdk` to 23 (needed by secure storage).
6. In `maya_ai_app/`:
       flutter pub get
       flutter run          # emulator or USB-connected phone
7. In the app: Settings -> set Backend URL and App token (same value as MAYA_APP_TOKEN in backend/.env).
   - Emulator: http://10.0.2.2:8000
   - Real phone on the same Wi-Fi: http://<your PC's IP>:8000 (backend started with --host 0.0.0.0)
8. Debug APK for testing:  flutter build apk --debug   -> build/app/outputs/flutter-apk/app-debug.apk
