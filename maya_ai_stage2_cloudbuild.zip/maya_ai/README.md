# MAYA AI
- `backend/` FastAPI server (holds the API keys) - see Stage 1 notes below
- `app/` Flutter app sources (lib + pubspec) - see docs/SETUP_STAGE2.md

## Run backend
    cd backend
    python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    cp .env.example .env        # add ANTHROPIC_API_KEY and MAYA_APP_TOKEN
    uvicorn app.main:app --host 0.0.0.0 --port 8000
