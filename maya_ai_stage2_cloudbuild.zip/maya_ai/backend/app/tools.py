import httpx
from duckduckgo_search import DDGS

WMO = {0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
       45: "fog", 48: "fog", 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle",
       61: "light rain", 63: "rain", 65: "heavy rain", 71: "light snow", 73: "snow",
       75: "heavy snow", 80: "rain showers", 81: "rain showers", 82: "violent rain showers",
       95: "thunderstorm", 96: "thunderstorm with hail", 99: "thunderstorm with hail"}


def web_search(query: str, n: int = 5) -> list[dict]:
    with DDGS() as ddgs:
        results = ddgs.text(query, max_results=n)
    return [{"title": r.get("title"), "url": r.get("href"), "snippet": r.get("body")} for r in results]


def news(query: str = "India", n: int = 5) -> list[dict]:
    with DDGS() as ddgs:
        results = ddgs.news(query, max_results=n)
    return [{"title": r.get("title"), "url": r.get("url"), "source": r.get("source"), "date": r.get("date")} for r in results]


async def weather(city: str) -> dict:
    async with httpx.AsyncClient(timeout=10) as c:
        g = await c.get("https://geocoding-api.open-meteo.com/v1/search",
                        params={"name": city, "count": 1})
        g.raise_for_status()
        res = g.json().get("results")
        if not res:
            return {"error": f"City '{city}' not found"}
        p = res[0]
        w = await c.get("https://api.open-meteo.com/v1/forecast", params={
            "latitude": p["latitude"], "longitude": p["longitude"],
            "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
            "timezone": "auto"})
        w.raise_for_status()
        cur = w.json()["current"]
        return {"city": p["name"], "country": p.get("country"),
                "temp_c": cur["temperature_2m"], "feels_like_c": cur["apparent_temperature"],
                "humidity": cur["relative_humidity_2m"], "wind_kmh": cur["wind_speed_10m"],
                "condition": WMO.get(cur["weather_code"], "unknown"), "time": cur["time"]}
