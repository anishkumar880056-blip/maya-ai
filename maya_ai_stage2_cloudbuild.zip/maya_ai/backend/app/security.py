import hmac
import time
from collections import defaultdict, deque
from fastapi import Header, HTTPException, Request
from . import config

_hits: dict[str, deque] = defaultdict(deque)


def require_app_token(x_maya_token: str = Header(default="")):
    """Reject requests that don't carry the shared app token."""
    if not config.APP_TOKEN or not hmac.compare_digest(x_maya_token, config.APP_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid or missing app token")


def rate_limit(request: Request):
    """Simple per-IP sliding-window limiter (per minute)."""
    ip = request.client.host if request.client else "unknown"
    now = time.time()
    q = _hits[ip]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= config.RATE_LIMIT_PER_MIN:
        raise HTTPException(status_code=429, detail="Too many requests")
    q.append(now)
