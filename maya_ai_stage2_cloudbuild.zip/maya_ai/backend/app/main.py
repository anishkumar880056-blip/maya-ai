import json
from typing import Literal
import anthropic
from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field
from . import config, tools
from .prompts import build_system_prompt
from .security import rate_limit, require_app_token

app = FastAPI(title="MAYA AI Backend", version="0.1.0")
client = anthropic.AsyncAnthropic(api_key=config.ANTHROPIC_API_KEY) if config.ANTHROPIC_API_KEY else None
guard = [Depends(rate_limit), Depends(require_app_token)]

TOOLS = [
    {"name": "web_search", "description": "Search the internet for current information.",
     "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}},
    {"name": "get_weather", "description": "Get current weather for a city.",
     "input_schema": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}},
    {"name": "get_news", "description": "Get latest news headlines on a topic.",
     "input_schema": {"type": "object", "properties": {"topic": {"type": "string"}}, "required": ["topic"]}},
]


class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=8000)


class ChatRequest(BaseModel):
    messages: list[Message] = Field(min_length=1, max_length=40)
    language: Literal["en", "hi"] = "en"
    personality: str = Field(default="", max_length=300)
    memory: list[str] = Field(default_factory=list, max_length=30)  # only items the user approved


class ChatResponse(BaseModel):
    reply: str
    used_tools: list[str] = []


async def run_tool(name: str, args: dict):
    if name == "web_search":
        return tools.web_search(args["query"])
    if name == "get_weather":
        return await tools.weather(args["city"])
    if name == "get_news":
        return tools.news(args["topic"])
    return {"error": "unknown tool"}


@app.get("/health")
async def health():
    return {"status": "ok", "ai_configured": client is not None}


@app.post("/chat", response_model=ChatResponse, dependencies=guard)
async def chat(req: ChatRequest):
    if client is None:
        raise HTTPException(503, "ANTHROPIC_API_KEY is not configured on the server")
    system = build_system_prompt(req.language, req.personality, req.memory)
    msgs = [m.model_dump() for m in req.messages]
    used: list[str] = []
    for _ in range(4):  # max tool-use rounds
        try:
            resp = await client.messages.create(model=config.MODEL, max_tokens=700,
                                                system=system, tools=TOOLS, messages=msgs)
        except anthropic.APIError as e:
            raise HTTPException(502, f"AI provider error: {e.__class__.__name__}")
        if resp.stop_reason != "tool_use":
            text = "".join(b.text for b in resp.content if b.type == "text").strip()
            return ChatResponse(reply=text, used_tools=used)
        msgs.append({"role": "assistant", "content": resp.content})
        results = []
        for b in resp.content:
            if b.type == "tool_use":
                used.append(b.name)
                try:
                    out = await run_tool(b.name, b.input)
                except Exception as e:  # tool failure must not crash the chat
                    out = {"error": str(e)}
                results.append({"type": "tool_result", "tool_use_id": b.id,
                                "content": json.dumps(out, ensure_ascii=False)})
        msgs.append({"role": "user", "content": results})
    raise HTTPException(500, "Too many tool rounds")


@app.get("/search", dependencies=guard)
async def search(q: str):
    return {"results": tools.web_search(q)}


@app.get("/weather", dependencies=guard)
async def weather(city: str):
    return await tools.weather(city)


@app.get("/news", dependencies=guard)
async def get_news(topic: str = "India"):
    return {"articles": tools.news(topic)}
